package com.chris.androidjetpack.databinding

data class Follower(var login: String, var id: Int, var avatar_url: String) {


}