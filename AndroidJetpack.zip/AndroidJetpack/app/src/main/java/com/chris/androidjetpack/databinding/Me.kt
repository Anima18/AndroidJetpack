package com.chris.androidjetpack.databinding

/**
 * Created by jianjianhong on 18-11-29
 */
class Me(var login: String, var avatar_url: String, var location: String, var bio: String) {
}